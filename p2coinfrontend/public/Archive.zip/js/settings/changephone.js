$('form').submit(function(){
    $('#phone_number').val($('#phone').val());
});