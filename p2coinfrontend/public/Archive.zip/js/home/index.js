/**
 * Created by administrator on 6/16/17.
 */
$(document).ready(function() {

});